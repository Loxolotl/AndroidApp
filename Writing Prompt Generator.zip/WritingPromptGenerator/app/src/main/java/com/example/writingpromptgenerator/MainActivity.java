package com.example.writingpromptgenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String[] prompt1 = {
            "A Dark fantasy story, ",
            "A Dark Si-Fi story, ",
            "A fantastical story, ",
            "A mysterious thriller, ",
            "A post-apocalyptic adventure, ",
            "A time-traveling epic, ",
            "A supernatural tale, ",
            "An otherworldly journey, ",
            "A dystopian saga, ",
            "A mythological odyssey, ",
            "A Gothic horror narrative, ",
            "A futuristic space opera, ",
            "A magical realism masterpiece, ",
            "A cyberpunk adventure, ",
            "A paranormal suspense, "
    };
    private String[] prompt2 = {
            "written like a murder mystery, ",
            "written like a hero story, ",
            "written like a report, ",
            "written like a psychological thriller, ",
            "written like a coming-of-age story, ",
            "written like a fantasy epic, ",
            "written like a science fiction adventure, ",
            "written like a courtroom drama, ",
            "written like a Gothic horror tale, ",
            "written like a romantic comedy, ",
            "written like a dystopian thriller, ",
            "written like a historical biography, ",
            "written like a satirical commentary, ",
            "written like a survival story, ",
            "written like a supernatural suspense, ",
            "written like a war chronicle, ",
            "written like a slice-of-life narrative, ",
            "written like a cyberpunk noir, "
    };
    private String[] prompt3 = {
            "set in a bottomless cavern, ",
            "set on a giant corpse, ",
            "set in deep space, ",
            "set in a haunted mansion, ",
            "set in a dystopian city, ",
            "set in a magical forest, ",
            "set on a deserted island, ",
            "set in a parallel universe, ",
            "set in an ancient civilization, ",
            "set in a post-apocalyptic wasteland, ",
            "set in a futuristic metropolis, ",
            "set in a small rural town, ",
            "set underwater in an abyss, ",
            "set in a time-traveling laboratory, ",
            "set in a virtual reality world, ",
            "set on a space station, ",
            "set in a mythical kingdom, ",
            "set in a war-torn country, ",
            "set in an enchanted castle, ",
            "set in a secret underground society, "
    };
    private String[] prompt4 = {
            "ending in a tragic twist. ",
            "ending in a subversion. ",
            "ending with a happy ending. ",
            "ending with a bittersweet resolution. ",
            "ending in a cliffhanger. ",
            "ending with a surprising revelation. ",
            "ending in an unexpected betrayal. ",
            "ending with a moral dilemma. ",
            "ending in an epic showdown. ",
            "ending with a triumphant comeback. ",
            "ending in a shocking sacrifice. ",
            "ending with a newfound understanding. ",
            "ending in a romantic reunion. ",
            "ending with a poignant farewell. ",
            "ending in a thrilling escape. ",
            "ending with a profound transformation. ",
            "ending in a dramatic confrontation. ",
            "ending with a mysterious disappearance. ",
            "ending in an ambiguous conclusion. ",
            "ending with a symbolic gesture. "
    };
    private String[] title1 = {
        "The ",
        ""
    };
    private String[] title2 = {
            "Secret ",
            "Lost ",
            "Forgotten ",
            "Eternal ",
            "Whispering ",
            "Mysterious ",
            "Cursed ",
            "Enchanted ",
            "Glimmering ",
            "Beneath ",
            "Silent ",
            "Shattered ",
            "Wandering ",
            "Echoes ",
            "Ethereal ",
            "Tangled ",
            "Infinite ",
            "Obsidian ",
            "Fading ",
            "Luminous ",
            "Vivid ",
            "Spectral ",
            "Shifting ",
            "Enigmatic ",
            ""
    };
    private String[] title3 = {
            "Chronicles",
            "Legacy",
            "Quest",
            "Journey",
            "Destiny",
            "Revelation",
            "Legacy",
            "Prophecy",
            "Encounter",
            "Chronicle",
            "Secrets",
            "Adventures",
            "Awakening",
            "Redemption",
            "Pursuit",
            "Dawn",
            "Echo",
            "Whispers",
            "Fall",
            "Rise",
            "Escape",
            "Return",
            "End",
            "Beginnings"
    };
    public String prompt = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int i = (int) (Math.random()* prompt1.length);
        String temp1 = prompt1[i];
        i = (int) (Math.random()* prompt2.length);
        String temp2 = prompt2[i];
        i = (int) (Math.random()* prompt3.length);
        String temp3 = prompt3[i];
        i = (int) (Math.random()* prompt4.length);
        String temp4 = prompt4[i];

        prompt = temp1+temp2+temp3+temp4;

        int j = (int) (Math.random()* title1.length);
        String tempTitle1 = title1[j];
        j = (int) (Math.random()* title2.length);
        String tempTitle2 = title2[j];
        j = (int) (Math.random()* title3.length);
        String tempTitle3 = title3[j];


        TextView title = (TextView) findViewById(R.id.textview2);
        title.setText(tempTitle1+tempTitle2+tempTitle3);

        TextView tv1 = (TextView) findViewById(R.id.textview);
        tv1.setText(temp1 + temp2 + temp3 + temp4);

    }
    public void change(View view) {
        int i = (int) (Math.random()* prompt1.length);
        String temp1 = prompt1[i];
        i = (int) (Math.random()* prompt2.length);
        String temp2 = prompt2[i];
        i = (int) (Math.random()* prompt3.length);
        String temp3 = prompt3[i];
        i = (int) (Math.random()* prompt4.length);
        String temp4 = prompt4[i];

        TextView tv1 = (TextView) findViewById(R.id.textview);
        tv1.setText(temp1 + temp2 + temp3 + temp4);

        int j = (int) (Math.random()* title1.length);
        String tempTitle1 = title1[j];
        j = (int) (Math.random()* title2.length);
        String tempTitle2 = title2[j];
        j = (int) (Math.random()* title3.length);
        String tempTitle3 = title3[j];


        TextView title = (TextView) findViewById(R.id.textview2);
        title.setText(tempTitle1+tempTitle2+tempTitle3);
    }
    public void clip(View view){
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText(prompt,prompt);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, "Copied to Clipboard!", Toast.LENGTH_SHORT).show();
    }
}